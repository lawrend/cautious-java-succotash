//package application;
import java.util.ArrayList;
import java.util.Collections;

public class ProjectList {
	private ArrayList<HProject> projList;
	
	public ProjectList() {
		projList = new ArrayList<>();
	}
	
//	public void addProject(Hproject p) {
//		projList.add(p);
//	}
	
//	public ArrayList<Hproject> getProjectList() {
//		Collections.checkedSortedMap(projList);
//		return projList;
//	}
	

}
