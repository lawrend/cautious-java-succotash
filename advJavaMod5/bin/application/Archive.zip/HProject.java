//package application;
import java.util.*;

public class HProject {
	private String projName;
	private int estCost;
	
	public HProject(String name, int estCost) {
		this.projName = name;
		this.estCost = estCost;
	}
	
	public HProject() {
		
	}
	
	public String getProjName() {
		return projName;
	}
	
	public void setProjName(String name) {
		this.projName = name;
	}
	
	public int getEstCost() {
		return estCost;
	}
	
	public void setEstCost(int cost) {
		this.estCost = cost;
	}
	
	public int getMonthlyCost() {
		return estCost/12;
	}

}
