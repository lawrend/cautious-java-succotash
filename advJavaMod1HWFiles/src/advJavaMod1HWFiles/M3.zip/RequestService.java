
public interface RequestService {
	public String pickService(String projNickname, int extraCost);
}
